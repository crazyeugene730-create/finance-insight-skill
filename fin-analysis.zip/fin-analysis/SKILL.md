---
name: fin-analysis
description: 财务分析skill，覆盖财报数据分析全流程；传入action选择功能：calc_metrics算指标、detect_anomalies找异常、diagnose做归因诊断、generate_report出报告
parameters:
  - name: action
    type: string
    required: true
    enum: ["calc_metrics", "detect_anomalies", "diagnose", "generate_report"]
    description: "要执行的动作。calc_metrics=计算财务指标（唯一产出数字的环节）；detect_anomalies=按阈值规则输出异常清单；diagnose=生成归因诊断任务包（交给模型补全四段式）；generate_report=生成九段式报告骨架（数字全部预填）"
  - name: data_file
    type: string
    required: false
    description: "财务数据文件路径，支持 .xlsx / .xlsm / .csv。格式：第一行表头（第一列科目名，其余列为年份，如 2023/2024/2025），不要合并单元格，金额单位必须统一。action=calc_metrics 时必填"
  - name: data
    type: string
    required: false
    description: "内联 CSV 文本，与 data_file 二选一，用于不方便落盘时直接传数据"
  - name: metrics
    type: string
    required: false
    description: "上一步 calc_metrics 产出的指标表（JSON 字符串或对象），传给 detect_anomalies / diagnose / generate_report 复用，避免重复计算"
  - name: anomalies
    type: string
    required: false
    description: "上一步 detect_anomalies 产出的异常清单（JSON 字符串或数组）。不传时脚本会自动重算一遍"
  - name: diagnoses
    type: string
    required: false
    description: "diagnose 环节由模型补全后的四段式结论（JSON 字符串或数组），传给 generate_report 填充第七章"
  - name: context
    type: string
    required: false
    description: "年报相关文本片段（管理层讨论、附注等），供 diagnose 找原因依据使用"
  - name: company
    type: string
    required: false
    description: "公司名称，用于报告标题与免责声明"
  - name: years_label
    type: string
    required: false
    description: "报告封面的期间表述，如 2023-2025；不传时用数据中的年份自动拼接"
  - name: industry
    type: string
    required: false
    enum: ["默认", "重资产", "强周期", "高周转零售", "项目制", "高研发"]
    description: "行业特性，用于提示阈值是否需要放宽或收紧。当前版本仅返回提示，阈值本体仍需在 references/threshold_rules.json 中调整"
  - name: top
    type: number
    required: false
    description: "diagnose 时限制处理的异常条数，默认处理全部高+中严重度异常"
  - name: outdir
    type: string
    required: false
    description: "输出目录，默认当前目录下的 fin_output"
---

# fin-analysis · 财务分析（单 Skill 多 Action）

一个 Skill 名字，通过 `action` 参数分发四种财务分析能力。**数字只在 `calc_metrics` 产生一次，后面三个环节只搬运、不计算。**

调用示例：

```json
{"name":"fin-analysis","params":{"action":"calc_metrics","data_file":"data.xlsx"}}
{"name":"fin-analysis","params":{"action":"detect_anomalies","metrics":"<上一步的metrics.json内容>"}}
{"name":"fin-analysis","params":{"action":"diagnose","anomalies":"<上一步的异常清单>","context":"年报管理层讨论原文"}}
{"name":"fin-analysis","params":{"action":"generate_report","company":"示例公司","diagnoses":"<模型补全的四段式>"}}
```

## 四个 Action 的分工

| action | 脚本做什么 | 模型做什么 |
|---|---|---|
| `calc_metrics` | 算 30+ 指标、同比、输出 CSV/MD/JSON | 只确认年份与科目识别是否正确 |
| `detect_anomalies` | 按阈值规则输出异常清单（含严重度、触发规则） | 判断是否需按行业回调阈值 |
| `diagnose` | 组装"诊断任务包"：异常 + 深挖路径 + 四段式模板 | 逐条补全四段式内容（核心判断环节） |
| `generate_report` | 生成九段骨架，所有数字预填、免责声明自动生成 | 补写各章定性文字（标记了【待补充】的地方） |

## 给模型的硬性要求

1. **不自己算数。** 报告里每个数字必须能在 `calc_metrics` 的输出里找到。缺数据就让用户补，不要估算、不要心算。
2. **原因必须有依据。** 四段式的"可能原因"要么是明确的数据关系（如"成本增速 15.3% > 收入增速 12.5%"），要么是年报原文并注明章节。推断的必须显式写"此为推断，需进一步核实"。
3. **不做投资建议。** 全文不出现买入/卖出/增持/目标价/估值判断。
4. **先规则后判断。** 异常是否成立由 `threshold_rules.json` 说了算，不要凭感觉挑异常。
5. **依据可追溯。** 引用年报时注明章节；数据关系要写出具体数字比较。

## 典型串法

```
calc_metrics(data_file)
   → detect_anomalies(metrics)
       → diagnose(anomalies, context)   ← 模型补全四段式
           → generate_report(metrics, anomalies, diagnoses, company)  ← 模型补写定性文字
```

每一步都可单独运行。用户只想要指标就跑第一步，只想看异常就跑到第二步。

## 扩展方式

1. `scripts/main.py` 新增 `handle_xxx(params)` 函数
2. `ACTION_MAP` 字典加一行 `"xxx": handle_xxx`
3. 本文件 frontmatter 的 `enum` 加上 `"xxx"`
4. 重新打包 zip

## 已知边界

- 只覆盖通用财务指标，不做行业专属指标（EV/EBITDA、同店增速等）。
- 周转率用期初期末平均；首年无上年数据，退化为期末口径。
- 不做合并报表调整与会计政策差异还原。
- 阈值是通用起点，必须按行业和真实案例持续校准（`references/threshold_rules.json`）。
- 无法识别财务造假，只能提示"数据与常识背离，需重点核实"。
