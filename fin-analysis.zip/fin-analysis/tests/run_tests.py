# -*- coding: utf-8 -*-
"""本地自测：依次跑通四个 action。运行：python tests/run_tests.py"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
import main  # noqa: E402

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "references", "sample_input.csv")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fin_output")


def show(title, obj, keys=None):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)
    if keys:
        obj = {k: obj.get(k) for k in keys}
    print(json.dumps(obj, ensure_ascii=False, indent=2)[:2200])


# 1 指标计算
r1 = main.execute({"action": "calc_metrics", "data_file": DATA, "outdir": OUT})
show("1. calc_metrics", r1, ["success", "years", "指标数量", "未识别科目", "files"])
metrics_payload = {"years": r1["years"], "metrics": r1["metrics"]}

# 2 异常识别
r2 = main.execute({"action": "detect_anomalies", "data_file": DATA, "metrics": metrics_payload, "outdir": OUT})
show("2. detect_anomalies", r2, ["success", "summary"])
print("命中规则：", [(a["规则编号"], a["严重度"], a["触发规则"]) for a in r2["anomalies"]])

# 3 诊断任务包
r3 = main.execute({"action": "diagnose", "data_file": DATA, "metrics": metrics_payload,
                   "anomalies": r2["anomalies"], "outdir": OUT})
show("3. diagnose", r3, ["success", "instruction"])
print("任务数：", len(r3["diagnosis_tasks"]))
if r3["diagnosis_tasks"]:
    print("首个任务：")
    print(json.dumps(r3["diagnosis_tasks"][0], ensure_ascii=False, indent=2))

# 4 报告骨架
fake = []
for t in r3["diagnosis_tasks"][:2]:
    fake.append({"异常编号": t["异常编号"], "指标": t.get("异常描述"),
                 "财务现象": "示例", "可能原因": "示例", "风险判断": "示例", "建议关注": "示例"})
r4 = main.execute({"action": "generate_report", "data_file": DATA, "metrics": metrics_payload,
                   "anomalies": r2["anomalies"], "diagnoses": fake,
                   "company": "示例股份有限公司", "years_label": "2023-2025", "outdir": OUT})
show("4. generate_report", r4, ["success", "待补充标记数", "files"])

# 5 边界：非法 action / 缺参数
print("\n" + "=" * 60)
print("5. 异常处理")
print("=" * 60)
print(json.dumps(main.execute({"action": "no_such"}), ensure_ascii=False))
print(json.dumps(main.execute({"action": "calc_metrics"}), ensure_ascii=False))
